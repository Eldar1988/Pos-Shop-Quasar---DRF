default_app_config = 'posshop.apps.PosshopConfig'
