from django.apps import AppConfig


class PosshopConfig(AppConfig):
    name = 'posshop'
    verbose_name = "1. Сайт"
