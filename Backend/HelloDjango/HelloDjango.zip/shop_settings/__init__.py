default_app_config = 'shop_settings.apps.ShopSettingsConfig'
