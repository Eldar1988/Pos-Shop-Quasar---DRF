from django.apps import AppConfig


class ShopConfig(AppConfig):
    name = 'shop'
    verbose_name = "2. Магазин"
