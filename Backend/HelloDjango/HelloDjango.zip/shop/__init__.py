default_app_config = 'shop.apps.ShopConfig'
